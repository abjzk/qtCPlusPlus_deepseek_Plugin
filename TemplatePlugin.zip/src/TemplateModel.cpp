﻿#include "TemplateModel.h"

TemplateModel::TemplateModel()
	:DBModel()
{
}

TemplateModel::~TemplateModel()
{
}
